国内开源镜像 

[centos 6.5 搭建lnmp环境](http://ju.outofmemory.cn/entry/77706)